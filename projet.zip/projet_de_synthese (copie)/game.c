/**
 * \file world.c
 * \brief partie logique des données du monde
*/

#include "game.h"
#include "sdl2-light.h"
#include <stdio.h>
#include <stdlib.h>
#include "sdl2-ttf-light.h"



void init_sprite(sprite_t *sprite, int x, int y, int w, int h){
    sprite->sprite_x=x;
    sprite->sprite_y=y;
    sprite->sprite_w=w;
    sprite->sprite_h=h; 
    sprite->make_disppear=0; 
}




void print_sprite(sprite_t *sprite){
    printf("sprite_x = %d \n", sprite->sprite_x);
    printf("sprite_y = %d\n", sprite->sprite_y);
    printf("spritex_w= %d\n", sprite->sprite_w);
    printf("sprite_h= %d\n", sprite->sprite_h);
}


void init_walls(world_t *world){
    float x[6]={48,252,16,188,48,252};
    float y[6]={0,0,-352,-352,-672,-693};
    float largeur[6]={96,96,32,224,96,96};
    float hauteur[6]={192,192,160,160,192,192};
    for (int i=0;i<6;i++){
        world->tab_mur[i].sprite_x=x[i];
        world->tab_mur[i].sprite_y=y[i];
        world->tab_mur[i].sprite_w=largeur[i];
        world->tab_mur[i].sprite_h=hauteur[i];
    }
}



void init_data(world_t * world){
    world->gameover =0;
    init_sprite(&world->vaisseau, SCREEN_WIDTH/2,SCREEN_HEIGHT-SHIP_SIZE,SHIP_SIZE,SHIP_SIZE );
    print_sprite(&world->vaisseau);
    init_sprite(&world->ligne_art, SCREEN_WIDTH/2,-1000,SCREEN_WIDTH,FINISH_LINE_HEIGHT );
    world->vy =INITIAL_SPEED;
    //init_sprite(&world->mur,SCREEN_WIDTH/2, SCREEN_HEIGHT/2, 3*METEORITE_SIZE, 7*METEORITE_SIZE); c pour le premier mur
    init_walls(world);
}








void clean_data(world_t *world){
    /* utile uniquement si vous avez fait de l'allocation dynamique (malloc); la fonction ici doit permettre de libérer la mémoire (free) */
    
}





int is_game_over(world_t *world){
    return world->gameover;
}


void limite_collision (sprite_t *sprite){
    if  ( sprite->sprite_x > SCREEN_WIDTH ){
        sprite->sprite_x=(SCREEN_WIDTH-sprite->sprite_w);
    }else if (sprite->sprite_x < 0){
        sprite->sprite_x=0 ;
    }
}



int sprites_collide(sprite_t *sprite1, sprite_t *sprite2){
    if  ( abs(sprite1->sprite_x - sprite2->sprite_x)<(sprite1->sprite_w/2 + sprite2->sprite_w/2)
            &&  abs(sprite1->sprite_y - sprite2->sprite_y)<(sprite1->sprite_h/2 + sprite2->sprite_h/2)  )      {
        return 1;
    }else{
        return 0;
    }

}



void  handle_sprites_collision(sprite_t* spr1 ,sprite_t* spr2,world_t *world){
    if (sprites_collide(spr1,spr2)==1){
        world->vy=0;
        spr1->make_disppear=1;
    }
}

void update_data(world_t *world){
    world->ligne_art.sprite_y += world->vy;
    // world->mur.sprite_y += world->vy;    c pour le premier mur
    limite_collision(&(world->vaisseau));
     //handle_sprites_collision( &(world->vaisseau) , &(world->mur), world);   c pour le premier mur
     for (int i=0;i<6;i++){
        handle_sprites_collision( &(world->vaisseau) , &(world->tab_mur[i]), world);
    }
    handle_sprites_collision( &(world->vaisseau) , &(world->ligne_art), world);
    update_walls(world);
}

void update_walls(world_t *world){
    for (int i=0;i<6;i++){
        world->tab_mur[i].sprite_y+=world->vy;
    } 
}

void handle_events(SDL_Event *event,world_t *world){
    Uint8 *keystates;
    while( SDL_PollEvent( event ) ) {
        
        //Si l'utilisateur a cliqué sur le X de la fenêtre
        if( event->type == SDL_QUIT ) {
            //On indique la fin du jeu
            world->gameover = 1;
        }
       
        //si une touche est appuyée
        if(event->type == SDL_KEYDOWN){
                //si la touche appuyée est '<'
    	     	if(event->key.keysym.sym == SDLK_LEFT){
              	 world->vaisseau.sprite_x= world->vaisseau.sprite_x - MOVING_STEP;
              	}
              	//si la touche appuyée est '>'
              	 if(event->key.keysym.sym == SDLK_RIGHT){
              	 world->vaisseau.sprite_x= world->vaisseau.sprite_x + MOVING_STEP;
              	}
                
                //si la touche appuyée est echap
                if(event->key.keysym.sym == SDLK_ESCAPE){
      
                    world->gameover = 1;    //pour sortir du jeu
                }
                //si la touche appuyée est la fleche du haut
                if(event->key.keysym.sym == SDLK_UP){

                    world->vy += PAS;  //pour accélérer la vitesse du mur et  de la ligne d'arrivée
                }
                //si la touche appuyée est la fleche du bas
                
                if(event->key.keysym.sym == SDLK_DOWN){

                    if(world->vy >0){  //Pour s'assurer de ne pas avoir une vitesse négative

                        world->vy -= PAS;  //pour ralentir la vitesse du mur et de la ligne d'arrivée
                    }
                }
    
         }
    }
}


