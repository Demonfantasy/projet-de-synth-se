var searchData=
[
  ['apply_5ftexture_0',['apply_texture',['../sdl2-light_8c.html#aa94de38ff23c16e13439cbe9cea15256',1,'apply_texture(SDL_Texture *texture, SDL_Renderer *renderer, int x, int y):&#160;sdl2-light.c'],['../sdl2-light_8h.html#aa94de38ff23c16e13439cbe9cea15256',1,'apply_texture(SDL_Texture *texture, SDL_Renderer *renderer, int x, int y):&#160;sdl2-light.c']]]
];
