var searchData=
[
  ['clean_5fsdl_0',['clean_sdl',['../sdl2-light_8c.html#a69f5b063948b40b1bac5bb2518ed9e52',1,'clean_sdl(SDL_Renderer *renderer, SDL_Window *window):&#160;sdl2-light.c'],['../sdl2-light_8h.html#a69f5b063948b40b1bac5bb2518ed9e52',1,'clean_sdl(SDL_Renderer *renderer, SDL_Window *window):&#160;sdl2-light.c']]],
  ['clean_5ftexture_1',['clean_texture',['../sdl2-light_8c.html#a6be5ef20bb308cf4f73ab911b33705e8',1,'clean_texture(SDL_Texture *texture):&#160;sdl2-light.c'],['../sdl2-light_8h.html#a6be5ef20bb308cf4f73ab911b33705e8',1,'clean_texture(SDL_Texture *texture):&#160;sdl2-light.c']]],
  ['clear_5frenderer_2',['clear_renderer',['../sdl2-light_8c.html#a572bf07064fc55f12238e71ba2930f5f',1,'clear_renderer(SDL_Renderer *renderer):&#160;sdl2-light.c'],['../sdl2-light_8h.html#a572bf07064fc55f12238e71ba2930f5f',1,'clear_renderer(SDL_Renderer *renderer):&#160;sdl2-light.c']]]
];
