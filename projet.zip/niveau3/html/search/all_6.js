var searchData=
[
  ['pause_0',['pause',['../sdl2-light_8c.html#a381e2d58c3d6a1f0fd8129bcc4726804',1,'pause(int time):&#160;sdl2-light.c'],['../sdl2-light_8h.html#a381e2d58c3d6a1f0fd8129bcc4726804',1,'pause(int time):&#160;sdl2-light.c']]]
];
