#ifndef SPRITE_H
#define SPRITE_H

#include "GameConstance.h"
#include "Texture.h"

/**
 * \brief Représentation du sprite du jeu
 */
struct sprite_s {
    int x, y, w, h;
    int visible;
};
/**
 * \brief Type qui correspond aux sprites
 */
typedef struct sprite_s sprite_t;

/**
 * \brief initialise les coordonées et la taille du sprite
 * \param sprite les donnée du sprite
 */
void init_sprite(sprite_t* sprite, int x, int y, int w, int h);
/**
 * \brief initialise le mur de météorites
 * \param wall le tableau de sprites
 * \param x la position de départ
 * \param y la position de départ
*/
void init_walls(sprite_t** wall, int x, int y);
/** 
 * \brief affiche les coordonées et sa taille du sprite
 * \param sprite les donnée du sprite
*/
void print_sprite(sprite_t* sprite);
/**
 * \brief La fonction détecte si un sprite dépasse trop à gache et remets bien au bord
 * \param sprite le sprite qui sera traité
 */
void colli_leftwindow(sprite_t* sprite);
/**
 * \brief La fonction détecte si un sprite dépasse trop à droite et remets bien au bord
 * \param sprite le sprite qui sera traité
 */
void colli_rightwindow(sprite_t* sprite);
/**
 * \brief La fonction qui renvoie si les deux sprites sont bien en collision
 * \param sp1 le premier sprite
 * \param sp2 le second sprite
 * \return 0 si les deux sprites ne sont pas en collision et 1 s'ils le sont bien
*/
int sprites_collide(sprite_t* sp1, sprite_t* sp2);


/**
 * \brief La fonction applique la texture du fond sur le renderer lié à l'écran de jeu
 * \param renderer le renderer
 * \param texture la texture liée au fond
*/
void apply_background(SDL_Renderer *renderer, SDL_Texture *texture);
/**
 * \brief La fonction applique la texture du sprite sur le renderer lié l'écran de jeu
 * \param renderer le renderer
 * \param texture la texture liée au sprite
 * \param sprite le sprite pour afficher à sa bonne position
 */
void apply_sprite(SDL_Renderer* renderer, SDL_Texture* texture, sprite_t* sprite);
/**
 * \brief affiche les météorites
 * \param renderer le renderer du jeu
 * \param texture la texture de la météorite
 * \prama world le monde du jeu
*/
void apply_walls(SDL_Renderer* renderer, SDL_Texture* texture, sprite_t* walls);

#endif