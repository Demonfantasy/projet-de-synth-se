#include "Texture.h"

void clean_textures(textures_t *textures){
    clean_texture(textures->background);
    clean_texture(textures->missile);
    clean_texture(textures->vaiseau);
    clean_texture(textures->finish_line);
    clean_texture(textures->meteorite);

    clean_font(textures->font);
}
void init_textures(SDL_Renderer *renderer, textures_t *textures){
    textures->background = load_image("ressources/space-background.bmp", renderer);
    textures->vaiseau = load_image("ressources/spaceship.bmp", renderer);
    textures->missile = load_image("ressources/missile.bmp", renderer);
    textures->finish_line = load_image("ressources/finish_line.bmp", renderer);
    textures->meteorite = load_image("ressources/meteorite.bmp", renderer);

    textures->font = load_font("ressources/light-arial.ttf", 12);
}