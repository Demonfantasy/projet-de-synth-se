#include "Sprite.h"

void init_sprite(sprite_t* sprite, int x, int y, int w, int h) {
    sprite->x = x;
    sprite->y = y;
    sprite->w = w;
    sprite->h = h;

    sprite->visible = 1; // je mets à 1 car il est déjà visible
}

void init_walls(sprite_t** wall, int ox, int oy) {
    // je définis la taille du tableau de sprite pour le nombre de météorites
    *wall = malloc((NB_WIDTH_METEOR * NB_HEIGHT_METEOR) * sizeof(sprite_t));

   // forme avec une boucle, nous parcours de 0 à nombre de météorites
    for(int y = 0; y < NB_HEIGHT_METEOR; y++) {
        for(int x = 0; x < NB_WIDTH_METEOR; x++) {
            init_sprite(*wall + (y * NB_WIDTH_METEOR) + x, 
                ox + x * METEORITE_SIZE, // je prends le milieu de l'écran, et je soustrait à la moitié de la taille de la largeur des météorite, pour que toutes mes météorites soient au centre de l'écran
                oy + y * METEORITE_SIZE, // j'ajoute FINISH_LINE_HEIGHT pour éviter que les météorites chauvachent la ligne d'arrivée
                METEORITE_SIZE, METEORITE_SIZE
            );
        }
    }
}

void print_sprite(sprite_t* sprite) { 
    printf("x: %d, y: %d, h: %d, w: %d\n", sprite->x, sprite->y, sprite->w, sprite->h); 
}

void colli_leftwindow(sprite_t* sprite) {
    if(sprite->x < 0) {
        sprite->x = 0;
    }
}
void colli_rightwindow(sprite_t* sprite) {
    if(sprite->x + sprite->w > SCREEN_WIDTH) {
        sprite->x = SCREEN_WIDTH - sprite->w;
    }
}

int sprites_collide(sprite_t* sp1, sprite_t* sp2) {
    if( (sp1->x + sp1->w > sp2->x)          && (sp1->y          < sp2->y + sp2->h) &&
        (sp1->x + sp1->w > sp2->x)          && (sp1->y + sp1->h > sp2->y) &&
        (sp1->x          < sp2->x + sp2->w) && (sp1->y + sp1->h > sp2->y) &&
        (sp1->x          < sp2->x + sp2->w) && (sp1->y          < sp2->y + sp2->h))
        return 1;
    return 0;
}

void apply_background(SDL_Renderer *renderer, SDL_Texture *texture){
    if(texture != NULL){
      apply_texture(texture, renderer, 0, 0);
    }
}
void apply_sprite(SDL_Renderer* renderer, SDL_Texture* texture, sprite_t* sprite) {
    if(texture != NULL)
        apply_texture(texture, renderer, sprite->x, sprite->y);
}
void apply_walls(SDL_Renderer* renderer, SDL_Texture* texture, sprite_t* walls) {
    for(int i = 0; i < NB_WIDTH_METEOR * NB_HEIGHT_METEOR; i++) { // parcours tous les sprites
        apply_sprite(renderer, texture, &walls[i]);
    }
}
