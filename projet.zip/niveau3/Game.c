#include <stdlib.h>
#include <stdio.h>
#include "Game.h"

void init_data(world_t* world){
    // initialisation des sprites
    init_sprite(&world->vaisseau, SCREEN_WIDTH / 2 - SHIP_SIZE / 2, SCREEN_HEIGHT - SHIP_SIZE, SHIP_SIZE, SHIP_SIZE);
    init_sprite(&world->missile, 0, SCREEN_HEIGHT + SHIP_SIZE, 10, 10);
    init_sprite(&world->finish_line, 0, FINISH_LINE_INIT_Y, FINISH_LINE_HEIGHT, FINISH_LINE_HEIGHT);
    
    // appelle la fonction pour initialisé toutes les météroites
    init_walls(&world->walls, SCREEN_WIDTH / 2 - METEORITE_SIZE * NB_WIDTH_METEOR / 2, FINISH_LINE_HEIGHT + FINISH_LINE_INIT_Y);
   
    // affiche les positions et la taille des sprites
    print_sprite(&world->vaisseau);
    print_sprite(&world->finish_line);

    // initialisation du vecteur y
    world->vy = INITIAL_SPEED;

    world->timeStartEndGame = 0;

    //on n'est pas à la fin du jeu
    world->gameover = 0;  
}
void init_walls(world_t *world){
    float x[6]={48,252,16,188,48,252};
    float y[6]={0,0,-352,-352,-672,-672};
    float largeur[6]={96,96,32,224,96,96};
    float hauteur[6]={192,192,160,160,192,192};
    for (int i=0;i<6;i++){
        world->tab_mur[i].sprite_x=x[i];
        world->tab_mur[i].sprite_y=y[i];
        world->tab_mur[i].sprite_w=largeur[i];
        world->tab_mur[i].sprite_h=hauteur[i];
    }
}

void clean_data(world_t *world){
    /* utile uniquement si vous avez fait de l'allocation dynamique (malloc); la fonction ici doit permettre de libérer la mémoire (free) */
    free(world->walls);
}
int is_game_over(world_t *world){
    return world->gameover;
}

void handle_sprites_collision(world_t* world, sprite_t* sp1, sprite_t* sp2, int make_disappear) {
    if(sprites_collide(sp1, sp2)) {
        sp1->visible = 0; // on met le sprite invisible
    }

    if(!make_disappear) {
        colli_leftwindow(&world->vaisseau);
        colli_rightwindow(&world->vaisseau);
    } else {
        sp1->x = -sp1->w; // pour être sûr qu'on ne voit pas le sprite dépasser le cadre
    }
}

void update_walls(world_t* world) {
    for(int i = 0; i < NB_WIDTH_METEOR * NB_HEIGHT_METEOR; i++) {
        if(world->walls[i].visible) // on ne veut qu'intéragir avec les météorites visible
            world->walls[i].y += world->vy;
            handle_sprites_collision(world, &world->vaisseau, &world->walls[i], !world->vaisseau.visible);   
    }
}

void update_data(world_t *world){
    world->finish_line.y += world->vy;
    update_walls(world);  

    if(!world->vaisseau.visible)
        world->timeStartEndGame++;
    if(world->timeStartEndGame > TIME_GAMEOVER_QUITGAME)
        world->gameover = 1;
}

void handle_events(SDL_Event *event, world_t *world){
    Uint8 *keystates;
    while( SDL_PollEvent( event ) ) {
        
        //Si l'utilisateur a cliqué sur le X de la fenêtre
        if( event->type == SDL_QUIT ) {
            //On indique la fin du jeu
            world->gameover = 1;
        }
       
         //si une touche est appuyée
         if(event->type == SDL_KEYDOWN){
            if(event->key.keysym.sym == SDLK_ESCAPE)
                world->gameover = 1;
            //si la touche appuyée est 'D'
            if(event->key.keysym.sym == SDLK_d){
                world->vaisseau.x += MOVING_STEP;
            }
            if(event->key.keysym.sym == SDLK_q){
                world->vaisseau.x -= MOVING_STEP;
            }
            if(event->key.keysym.sym == SDLK_UP) {
                world->vy += 2;
            }
            if(event->key.keysym.sym == SDLK_DOWN) {
                world->vy -= 2;
            }
         }
    }
}
void refresh_graphics(SDL_Renderer *renderer, world_t *world,textures_t *textures){
    //on vide le renderer
    clear_renderer(renderer);
    
    //application des textures dans le renderer
    apply_background(renderer, textures->background);
    apply_sprite(renderer, textures->missile, &world->missile);
    apply_sprite(renderer, textures->vaiseau, &world->vaisseau);
    apply_sprite(renderer, textures->finish_line, &world->finish_line);
    // application de toutes les sprites des météorites
    apply_walls(renderer, textures->meteorite, world->walls);

    if(!world->vaisseau.visible) // si le vaisseau n'est plus visible à l'écran
		apply_text(renderer, 0, 0, SCREEN_WIDTH, SCREEN_WIDTH / 3, "Vous avez perdu", textures->font);

    // on met à jour l'écran
    update_screen(renderer);
}
void clean(SDL_Window *window, SDL_Renderer * renderer, textures_t *textures, world_t * world){
    clean_data(world);
    clean_textures(textures);
    clean_sdl(renderer,window);
}
void init(SDL_Window **window, SDL_Renderer ** renderer, textures_t *textures, world_t * world){
    init_sdl(window,renderer,SCREEN_WIDTH, SCREEN_HEIGHT);
    init_ttf(); // on n'oublie pas d'initialiser le ttf sinon ça ne fonction pas !!!
    init_data(world);
    init_textures(*renderer, textures);
}
