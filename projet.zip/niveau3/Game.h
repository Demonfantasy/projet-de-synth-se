#ifndef GAME_H
#define GAME_H

#include "sdl2-light.h"
#include "Sprite.h"

#include "GameConstance.h"

/**
 * \brief Représentation du monde du jeu
*/
struct world_s{
    sprite_t missile;
    sprite_t vaisseau;
    sprite_t finish_line;

    sprite_t* walls;

    unsigned int vy;

    int timeStartEndGame;

    int gameover; /*!< Champ indiquant si l'on est à la fin du jeu */
};
/**
 * \brief Type qui correspond aux données du monde
 */
typedef struct world_s world_t;

/**
 * \brief La fonction initialise les données du monde du jeu
 * \param world les données du monde
 */
void init_data(world_t* world);
/**
 * \brief La fonction nettoie les données du monde
 * \param world les données du monde
 */
void clean_data(world_t *world);
/**
 * \brief La fonction indique si le jeu est fini en fonction des données du monde
 * \param world les données du monde
 * \return 1 si le jeu est fini, 0 sinon
 */
int is_game_over(world_t *world);
/**
 * \brief La fonction met à jour les données en tenant compte de la physique du monde
 * \param les données du monde
 */
void update_data(world_t *world);
void update_wall(world_t *world);
/**
 * \brief La fonction gère les évènements ayant eu lieu et qui n'ont pas encore été traités
 * \param event paramètre qui contient les événements
 * \param world les données du monde
 */
void handle_events(SDL_Event *event, world_t *world);
/**
 * \brief La fonction met la vélocité y du mode à 0 si deux sprites sont en collision
 * \param world le monde du jeu
 * \param sp1 le premier sprite
 * \param sp2 le second sprite
*/
void handle_sprites_collision(world_t* world, sprite_t* sp1, sprite_t* sp2, int make_disappear);
/**
 * \brief La fonction rafraichit l'écran en fonction de l'état des données du monde
 * \param renderer le renderer lié à l'écran de jeu
 * \param world les données du monde
 * \param textures les textures
 */
void refresh_graphics(SDL_Renderer *renderer, world_t *world,textures_t *textures);
/**
* \brief fonction qui nettoie le jeu: nettoyage de la partie graphique (SDL), nettoyage des textures, nettoyage des données
* \param window la fenêtre du jeu
* \param renderer le renderer
* \param textures les textures
* \param world le monde
*/
void clean(SDL_Window *window, SDL_Renderer * renderer, textures_t *textures, world_t * world);
/**
 * \brief fonction qui initialise le jeu: initialisation de la partie graphique (SDL), chargement des textures, initialisation des données
 * \param window la fenêtre du jeu
 * \param renderer le renderer
 * \param textures les textures
 * \param world le monde
 */
void init(SDL_Window **window, SDL_Renderer ** renderer, textures_t *textures, world_t * world);

#endif /* GAME_H */
