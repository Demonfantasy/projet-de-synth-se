/**
 * \file world.h
 * \brief en-tête de la partie logique des données du monde
*/
#ifndef WORLD_H
#define WORLD_H
#include "constantes.h"
#include "sdl2-light.h"
#include "math.h"
#include "sdl2-ttf-light.h"




/**
 * \brief Coordonnés d'un élément du monde du jeu
*/
struct sprite_s{
    int sprite_x;  //Champ indiquant les coordonnées horizontales du repére de la place du personage  
   	int sprite_y; //Champ indiquant les coordonnées verticales du repére de la place du personage
   	int sprite_h; //Champ indiquant les coordonnées de la hauteur
   	int sprite_w; //Champ indiquant les coordonnées de la largeur
    int make_disppear;
   	};
/**
 * \brief Type qui correspond aux coordonnées des éléments du jeu
 */    
typedef struct sprite_s sprite_t; 






/**
 * \brief Représentation du monde du jeu
*/
struct world_s{
    
    sprite_t vaisseau;
    sprite_t ligne_art;
    float vy;
    int gameover;                                                /*!< Champ indiquant si l'on est à la fin du jeu */
    //sprite_t mur ;                                             c pour le premier mur
    sprite_t tab_mur[6];
};
/**
 * \brief Type qui correspond aux données du monde
 */
typedef struct world_s world_t;





/**
 * \brief La fonction qui initialise les coordonnées des éléments
 * \param sprite Un élément du jeu
 * \param x abscisse du sprite
 * \param y oronnéee du sprite
 * \param w 
largeur du sprite
 * \param h hauteur du sprite
 */
void init_sprite(sprite_t *sprite, int x, int y, int w, int h);





/**
 * \brief La fonction qui affiche les positions du sprite
 * \param sprite Un élement du jeu
 */
void print_sprite(sprite_t *sprite);





/**
 * \brief La fonction initialise les données du monde du jeu
 * \param world les données du monde
 */
void init_data(world_t * world);





/**
 * \brief La fonction nettoie les données du monde
 * \param world les données du monde
 */
void clean_data(world_t *world);





/**
 * \brief La fonction indique si le jeu est fini en fonction des données du monde
 * \param world les données du monde
 * \return 1 si le jeu est fini, 0 sinon
 */

 int is_game_over(world_t *world);





/**
 * \brief La fonction met à jour les données en tenant compte de la physique du monde
 * \param les données du monde
 */

 void update_data(world_t *world);





/**
 * \brief La fonction met a jour les données du mur
 * \param  world les données du monde
 */

 void update_walls(world_t *world);
    
    


 /**
 * \brief La fonction gère les évènements ayant eu lieu et qui n'ont pas encore été traités
 * \param event paramètre qui contient les événements
 * \param world les données du monde
 */
void handle_events(SDL_Event *event,world_t *world); 




 /**
 * \brief La fonction replace le sprite  quand ca sort de l'écran
 * \param sprite paramètre qui contient le bonhomme
 */
 void limite_collision (sprite_t *sprite);
 
 
 
 
  /**
 * \brief La fonction indique si les sprite sont en collision 
 * \param 2 sprites
 */
 int sprites_collide(sprite_t *sp1, sprite_t *sp2);



 
 
/**
 * \brief La fonction rend la vitesse NULL  si les sprite sont en collision 
 * \param 2 sprites et le world
 */
void  handle_sprites_collision(sprite_t *spr1 ,sprite_t *spr2,world_t* world);



/**
 * \brief fonction qui donne leur  position initiale aux meteorites pour former plusieurs murs de meteorites
 * \param world le monde du jeu
*/
void init_walls(world_t *world);
#endif
