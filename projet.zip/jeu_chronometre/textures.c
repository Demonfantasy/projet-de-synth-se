/**
 * \file graphiques.c
 * \brief partie graphique des données du monde
*/

#include "textures.h"
#include <stdio.h>
#include "sdl2-light.h"
#include "sdl2-ttf-light.h"





void clean_textures(textures_t *textures){
    clean_texture(textures->background);
    clean_texture(textures->vaisseau);
    clean_texture(textures->ligne_art);
    clean_texture(textures->meteorite);
    /* A COMPLETER */
    
}




void  init_textures(SDL_Renderer *renderer, textures_t *textures){
    textures->background = load_image( "ressources/space-background.bmp",renderer);
    textures->vaisseau = load_image( "ressources/spaceship.bmp",renderer);
    textures->ligne_art = load_image( "ressources/finish_line.bmp",renderer);
    textures->meteorite = load_image( "ressources/meteorite.bmp",renderer);
    /* deja fait */
  
}





void apply_background(SDL_Renderer *renderer, SDL_Texture *texture){
    if(texture != NULL){
      apply_texture(texture, renderer, 0, 0);
    }
}


void apply_walls(SDL_Renderer *renderer,SDL_Texture *texture,sprite_t * sprite){
    for (int i = 0; i < sprite->sprite_w / METEORITE_SIZE; i++) {
        for (int j = 0; j < sprite->sprite_h / METEORITE_SIZE; j++) {
            apply_texture(texture, renderer, sprite->sprite_x + i * METEORITE_SIZE - sprite->sprite_w / 2, sprite->sprite_y + j * METEORITE_SIZE - sprite->sprite_h / 2);
        }
    }
}


void apply_sprite(SDL_Texture *texture,SDL_Renderer *renderer,sprite_t *sprite){
    if(texture != NULL && sprite->make_disppear == 0) {
        apply_texture(texture, renderer, sprite->sprite_x - sprite->sprite_w/2, sprite->sprite_y-sprite->sprite_h/2 ) ;
    }
 }






void refresh_graphics(SDL_Renderer *renderer, world_t *world,textures_t *textures){
                                                                                      //on vide le renderer
    clear_renderer(renderer);
                                                                                      //application des textures dans le renderer
    apply_background(renderer, textures->background);
    apply_sprite(textures->vaisseau,renderer,&world->vaisseau);
    apply_sprite(textures->ligne_art,renderer,&world->ligne_art);
    /*  c'est pour   le premier mur
    for (int i = 0 ;i<3 ;i++){
        for (int j = 0 ;j<7 ;j++){
            apply_texture(textures->meteorite, renderer, world->mur.sprite_x + i * METEORITE_SIZE - world->mur.sprite_w / 2, world->mur.sprite_y + j * METEORITE_SIZE - world->mur.sprite_h / 2);
        }
    }
w   */
    for (int i = 0; i < 6; i++) {

        apply_walls(renderer, textures->meteorite, &world->tab_mur[i]); //on utilise une boucle pour afficher chaque mur

    }

    update_screen(renderer);                                    // on met à jour l'écran
}






void clean(SDL_Window *window, SDL_Renderer * renderer, textures_t *textures, world_t * world){
    clean_data(world);
    clean_textures(textures);
    clean_sdl(renderer,window);
}





void init(SDL_Window **window, SDL_Renderer ** renderer, textures_t *textures, world_t * world){
    init_sdl(window,renderer,SCREEN_WIDTH, SCREEN_HEIGHT);
    init_data(world);
    init_textures(*renderer,textures);
}


