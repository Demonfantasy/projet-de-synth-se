/**
 * \file Sprite.c
 * \author MAYER Tristan et MORSLI Lydia
 * \version 1.0
 * \date 28 avril 2025
*/

#include "Sprite.h"

void init_sprite(sprite_t* sprite, int x, int y, int w, int h) {
    sprite->x = x;
    sprite->y = y;
    sprite->w = w;
    sprite->h = h;

    sprite->visible = 1; 
}

void init_walls(sprite_t** wall, int ox, int oy) {
    *wall = malloc((NB_WIDTH_METEOR * NB_HEIGHT_METEOR) * sizeof(sprite_t));

   
    for(int y = 0; y < NB_HEIGHT_METEOR-1; y++) {
        for(int x = 0; x < NB_WIDTH_METEOR; x++) {
            init_sprite(*wall + (y * NB_WIDTH_METEOR) + x, 
                ox + x * METEORITE_SIZE, // centrage   
                oy + y * METEORITE_SIZE, //centreage
                METEORITE_SIZE, METEORITE_SIZE
            );
        }
    }
}

void print_sprite(sprite_t* sprite) { 
    printf("x: %d, y: %d, h: %d, w: %d\n", sprite->x, sprite->y, sprite->w, sprite->h); 
}

void colli_leftwindow(sprite_t* sprite) {
    if(sprite->x < 0) {
        sprite->x = 0;
    }
}
void colli_rightwindow(sprite_t* sprite) {
    if(sprite->x + sprite->w > SCREEN_WIDTH) {
        sprite->x = SCREEN_WIDTH - sprite->w;
    }
}

int sprites_collide(sprite_t* sp1, sprite_t* sp2) {
    if( (( abs( sp1->x - sp2->x ) <= (sp1->w + sp2->w ) / 2 ) && (abs( sp1->y - sp2->y ) <= ( sp1->h + sp2->h ) / 2 )))
        return 1;
    return 0;
}

void apply_background(SDL_Renderer *renderer, SDL_Texture *texture){
    if(texture != NULL){
      apply_texture(texture, renderer, 0, 0);
    }
}
void apply_sprite(SDL_Renderer* renderer, SDL_Texture* texture, sprite_t* sprite) {
    if(texture != NULL)
        apply_texture(texture, renderer, sprite->x, sprite->y);
}
void apply_walls(SDL_Renderer* renderer, SDL_Texture* texture, sprite_t* walls) {
    for(int i = 0; i < NB_WIDTH_METEOR * NB_HEIGHT_METEOR; i++) { // parcours tous les sprites
        apply_sprite(renderer, texture, &walls[i]);
    }
}
