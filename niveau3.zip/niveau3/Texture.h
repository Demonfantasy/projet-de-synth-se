/**
 * \file Sprite.c
 * \author MAYER Tristan et MORSLI Lydia
 * \version 1.0
 * \date 28 avril 2025
*/


#ifndef TEXTURE_H
#define TEXTURE_H

#include "sdl2-light.h"
#include "sdl2-ttf-light.h"

/**
 * \brief stock les textures nécessaires à l'affichage graphique
*/
struct textures_s{
    SDL_Texture* background;
    SDL_Texture* vaiseau;
    SDL_Texture* missile;
    SDL_Texture* finish_line;
    SDL_Texture* meteorite;

    TTF_Font* font;
};
/**
 * \brief Type qui correspond aux textures
*/
typedef struct textures_s textures_t;

/**
 * \brief La fonction nettoie les textures
 * \param textures textures
*/
void clean_textures(textures_t *textures);
/**
 * \brief La fonction initialise les textures nécessaires à l'affichage graphique du jeu
 * \param screen la surface correspondant à l'écran de jeu
 * \param textures textures
*/
void init_textures(SDL_Renderer *renderer, textures_t *textures);

#endif