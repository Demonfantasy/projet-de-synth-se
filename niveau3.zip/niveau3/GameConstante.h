#ifndef GAMECONSTANTE_H
#define GAMECONSTANTE_H

/**
 * \brief Largeur de l'écran de jeu
 */
#define SCREEN_WIDTH 300
/**
 * \brief Hauteur de l'écran de jeu
 */
#define SCREEN_HEIGHT 480
/**
 * \brief Taille d'un vaisseau
 */
#define SHIP_SIZE 32
/**
 * \brief Taille d'un météorite
*/
#define METEORITE_SIZE 32
/**
 * \brief Hauteur de la ligne d'arrivée
 */
#define FINISH_LINE_HEIGHT 10
/**
 * \brief Pas de déplacement horizontal du vaisseau
*/
#define MOVING_STEP 10
/**
  * \brief Vitesse initiale de déplacement vertical des éléments du jeu 
*/
#define INITIAL_SPEED 2
/**
 * \brief le nombre de météorites à sa largeur
 */
#define NB_WIDTH_METEOR 4
/**
 * \brief le nombre de météorites à sa hauteur
 */
#define NB_HEIGHT_METEOR 10
/**
 * \brief la postion de la ligne d'arriée
*/
#define FINISH_LINE_INIT_Y 10
/**
 * \brief donne le temps donné quand le jeu donne le gameover avant qu'il se ferme
*/
#define TIME_GAMEOVER_QUITGAME 100

#endif
