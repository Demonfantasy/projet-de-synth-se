var searchData=
[
  ['load_5fimage_0',['load_image',['../sdl2-light_8c.html#a506433ce183d5aa2b0bf551533fafee3',1,'load_image(const char path[], SDL_Renderer *renderer):&#160;sdl2-light.c'],['../sdl2-light_8h.html#a506433ce183d5aa2b0bf551533fafee3',1,'load_image(const char path[], SDL_Renderer *renderer):&#160;sdl2-light.c']]]
];
