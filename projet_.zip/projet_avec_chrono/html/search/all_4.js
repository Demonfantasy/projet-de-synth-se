var searchData=
[
  ['init_5fsdl_0',['init_sdl',['../sdl2-light_8c.html#a7307299b4ef47feaa1a4e95341a04c7a',1,'init_sdl(SDL_Window **window, SDL_Renderer **renderer, int width, int height):&#160;sdl2-light.c'],['../sdl2-light_8h.html#a7307299b4ef47feaa1a4e95341a04c7a',1,'init_sdl(SDL_Window **window, SDL_Renderer **renderer, int width, int height):&#160;sdl2-light.c']]]
];
