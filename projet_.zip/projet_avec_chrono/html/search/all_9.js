var searchData=
[
  ['update_5fscreen_0',['update_screen',['../sdl2-light_8c.html#adaf353d9ae01b52dd37cd0adf2d5c9ee',1,'update_screen(SDL_Renderer *renderer):&#160;sdl2-light.c'],['../sdl2-light_8h.html#adaf353d9ae01b52dd37cd0adf2d5c9ee',1,'update_screen(SDL_Renderer *renderer):&#160;sdl2-light.c']]]
];
