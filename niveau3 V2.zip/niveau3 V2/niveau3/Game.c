/**
 * \file Sprite.c
 * \author MAYER Tristan et MORSLI Lydia
 * \version 1.0
 * \date 28 avril 2025
*/


#include <stdlib.h>
#include <stdio.h>
#include "Game.h"

void init_walls(sprite_t** walls) {
    *walls = malloc(sizeof(sprite_t) * 6); // Allocation pour 6 murs
    // Initialisation des murs
    init_sprite(&(*walls)[0], 48, 0, 96, 192);
    init_sprite(&(*walls)[1], 252, 0, 96, 192);
    init_sprite(&(*walls)[2], 16, -352, 32, 160);
    init_sprite(&(*walls)[3], 188, -352, 224, 160);
    init_sprite(&(*walls)[4], 48, -672, 96, 192);
    init_sprite(&(*walls)[5], 252, -672, 96, 192);
}


void init_data(world_t* world) {
    // Initialisation des sprites
    init_sprite(&world->vaisseau, SCREEN_WIDTH / 2 - SHIP_SIZE / 2, SCREEN_HEIGHT - SHIP_SIZE, SHIP_SIZE, SHIP_SIZE);
    init_sprite(&world->missile, 0, SCREEN_HEIGHT + SHIP_SIZE, 10, 10);
    init_sprite(&world->finish_line, 0, FINISH_LINE_INIT_Y, FINISH_LINE_HEIGHT, FINISH_LINE_HEIGHT);
    
    // Initialisation des murs de météorites
    init_walls(&world->walls);

    world->finish_line.y = FINISH_LINE_INIT_Y; // Assurez-vous que c'est -960
    
    // Affichage des positions et tailles des sprites
    print_sprite(&world->vaisseau);
    print_sprite(&world->finish_line);

    // Initialisation de y
    world->vy = INITIAL_SPEED;
    world->timeStartEndGame = 0;
    world->gameover = 0;  
}

void clean_data(world_t *world){
    free(world->walls);
}

int is_game_over(world_t *world){
    return world->gameover;
}


// collision 
void handle_sprites_collision(world_t* world, sprite_t* sp1, sprite_t* sp2, int make_disappear) {
    if(sprites_collide(sp1, sp2)) {
        sp1->visible = 0; 
    }

    if(!make_disappear) {
        colli_leftwindow(&world->vaisseau);
        colli_rightwindow(&world->vaisseau);
    } else {
        sp1->x = -sp1->w; 
    }
}

void update_walls(world_t* world) {
    for(int i = 0; i < 6; i++) { // 6 murs
        if(world->walls[i].visible) {
            world->walls[i].y += world->vy; // Déplacement vers le bas
            handle_sprites_collision(world, &world->vaisseau, &world->walls[i], !world->vaisseau.visible);   
        }
    }
}


void update_data(world_t *world) {
    world->finish_line.y += world->vy;
    update_walls(world);  

    if(!world->vaisseau.visible) {
        world->timeStartEndGame++;
        if(world->timeStartEndGame > TIME_GAMEOVER_QUITGAME) {
            world->gameover = 1;
            printf("You lost!\n");
        }
    } else {
        printf("You finished in %d s!\n", world->timeStartEndGame / 1000);
    }
}

// mouvement et intéraction fenêtre
void handle_events(SDL_Event *event, world_t *world){
    Uint8 *keystates;
    while( SDL_PollEvent( event ) ) {
        
        
        if( event->type == SDL_QUIT ) {
            world->gameover = 1;
        }
       
         //si une touche est appuyée
         if(event->type == SDL_KEYDOWN){
            if(event->key.keysym.sym == SDLK_ESCAPE)
                world->gameover = 1;
            //si la touche appuyée est 'D'
            if(event->key.keysym.sym == SDLK_d){
                world->vaisseau.x += MOVING_STEP;
            }
            if(event->key.keysym.sym == SDLK_q){
                world->vaisseau.x -= MOVING_STEP;
            }
            if(event->key.keysym.sym == SDLK_UP) {
                world->vy += 2;
            }
            if(event->key.keysym.sym == SDLK_DOWN) {
                world->vy -= 2;
            }
         }
    }
}

void apply_walls(SDL_Renderer *renderer, sprite_t* walls) {
    for(int i = 0; i < 6; i++) {
        apply_sprite(renderer, textures->meteorite, &walls[i]);
    }
}


// textures / renderer
void refresh_graphics(SDL_Renderer *renderer, world_t *world, textures_t *textures) {
    clear_renderer(renderer);
    apply_background(renderer, textures->background);
    apply_sprite(renderer, textures->missile, &world->missile);
    apply_sprite(renderer, textures->vaiseau, &world->vaisseau);
    apply_sprite(renderer, textures->finish_line, &world->finish_line);
    apply_walls(renderer, world->walls); // Afficher les murs

    if(!world->vaisseau.visible) 
        apply_text(renderer, 0, 0, SCREEN_WIDTH, SCREEN_WIDTH / 3, "Vous avez perdu", textures->font);
    update_screen(renderer);
}


void clean(SDL_Window *window, SDL_Renderer * renderer, textures_t *textures, world_t * world){
    clean_data(world);
    clean_textures(textures);
    clean_sdl(renderer,window);
}

void init(SDL_Window **window, SDL_Renderer ** renderer, textures_t *textures, world_t * world){
    init_sdl(window,renderer,SCREEN_WIDTH, SCREEN_HEIGHT);
    init_ttf();
    init_data(world);
    init_textures(*renderer, textures);
}
