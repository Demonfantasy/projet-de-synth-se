/**
 * \file Sprite.c
 * \author MAYER Tristan et MORSLI Lydia
 * \version 1.0
 * \date 28 avril 2025
*/


#include "sdl2-ttf-light.h"

/**
 * \brief La fonction initialise l'environnement TTF
*/

void init_ttf(){
    if(TTF_Init()==-1) {
        printf("TTF_Init: %s\n", TTF_GetError());
    }
}


/**
 * \brief La fonction charge une police
 * \param path le chemin du fichier
 * \param font_size la taille de la police
 * \return la police chargée
*/

TTF_Font * load_font(const char *path, int font_size){
    TTF_Font *font = TTF_OpenFont(path, font_size);
    if(font == NULL){
        fprintf(stderr, "Erreur pendant chargement font: %s\n", SDL_GetError());
    }
    return font;
}


/**
 * \brief La fonction applique un texte dans une certaine police
 * \param renderer renderer
 * \param x abscisse 
 * \param y abscisse
 * \param w largeur du message
 * \param h hauteur
 * \param text texte à afficher
 * \param font police
*/


void apply_text(SDL_Renderer *renderer,int x, int y, int w, int h, const char *text, TTF_Font *font){
    SDL_Color color = { 255, 0, 255 };
    
    SDL_Surface* surface = TTF_RenderText_Solid(font, text, color);
    //printf("FFFFF\n");
     
    SDL_Texture* texture = SDL_CreateTextureFromSurface(renderer, surface);
    SDL_Rect dstrect2 = {x, y, w, h};
    SDL_RenderCopy(renderer, texture, NULL, &dstrect2);
    
}

void clean_font(TTF_Font * font){
    TTF_CloseFont(font);
}
